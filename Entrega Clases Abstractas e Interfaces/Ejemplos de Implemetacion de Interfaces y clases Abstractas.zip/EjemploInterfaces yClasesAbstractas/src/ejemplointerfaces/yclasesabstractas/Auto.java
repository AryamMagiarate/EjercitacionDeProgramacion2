/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemplointerfaces.yclasesabstractas;

/**
 *
 * @author Mayra M.F
 */
public class Auto extends Aparato implements OnOff{
    private String motor;
    
    public Auto(String motor, String nroSerie, String modelo, String fabricante) {
        super(nroSerie, modelo, fabricante);
        this.motor = motor;
    }

    public Auto(){// Constructor Vacio
    }
    

 
    public String getMotor() {
        return motor;
    }

    public void setMotor(String motor) {
        this.motor = motor;
    }

    @Override
    public void encender() {
        System.out.println("El auto está en marcha");
    }

    @Override
    public void apagar() {
        System.out.println("El auto esta apagado.");
    }

    @Override
    public String darDetalles() {
        System.out.println("--------------------------------------------------------------------------------------------------------------");
        String detalles="Información Auto:"+"\nMotor  "+getMotor()+"\nNúmero de Serie  "+getNroSerie()+"\nModelo  "+getModelo()+"\nFabricante  "+getFabricante();
        System.out.println("--------------------------------------------------------------------------------------------------------------");
       return detalles; 
    }
     
    
    
}
