/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemplointerfaces.yclasesabstractas;

/**
 *
 * @author Mayra M.F
 */
public class Computadora extends Aparato implements OnOff{
    private String teclado;

    public Computadora(String teclado, String nroSerie, String modelo, String fabricante) {
        super(nroSerie, modelo, fabricante);
        this.teclado = teclado;
    }

    public Computadora(){
    }
    public String getTeclado() {
        return teclado;
    }

    public void setTeclado(String teclado) {
        this.teclado = teclado;
    }

    @Override
    public void encender() {
        System.out.println("La computadora está encendida.");
    }

    @Override
    public void apagar() {
        System.out.println("La computadora está apagada.");
    }
     @Override
    public String darDetalles() {
         System.out.println("---------------------------------------------------------------------------------------------------------");
        String detalles="Información Computadora: "+"\nTeclado "+getTeclado()+"\nNúmero de Serie "+getNroSerie()+"\nModelo "+getModelo()+"\nFabricante "+getFabricante();
         System.out.println("---------------------------------------------------------------------------------------------------------");
       return detalles; 
    }
    
}
