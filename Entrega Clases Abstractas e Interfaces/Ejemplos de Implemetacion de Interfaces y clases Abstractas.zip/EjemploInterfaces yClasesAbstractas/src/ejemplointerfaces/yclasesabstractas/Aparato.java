/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemplointerfaces.yclasesabstractas;

/**
 *
 * @author Mayra M.F
 */
public abstract class Aparato {
    String nroSerie;
    private String modelo;
    private String fabricante;

    public Aparato(String nroSerie, String modelo, String fabricante) {
        this.nroSerie = nroSerie;
        this.modelo = modelo;
        this.fabricante = fabricante;
    }
    public Aparato(){ // constructor Vacio (si quiero que todas las clases que hereden a esta puedan construir un constructor vacio entonces debo ponerlo en la clase padre)
    
    }

    public String getNroSerie() {
        return nroSerie;
    }

    public void setNroSerie(String nroSerie) {
        this.nroSerie = nroSerie;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getFabricante() {
        return fabricante;
    }

    public void setFabricante(String fabricante) {
        this.fabricante = fabricante;
    }
    
    
}
