/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemplointerfaces.yclasesabstractas;

/**
 *
 * @author Mayra M.F
 */
public class EjemploInterfacesYClasesAbstractas {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      Auto a1=new Auto();
      Computadora compu1=new Computadora("Genius","23548lp","HP1003","HP");
      Televisor tele1=new Televisor();
      a1.setFabricante("Audi");
        System.out.println(a1.darDetalles());
      tele1.encender();
        System.out.println(tele1.darDetalles());
    }
    
}
