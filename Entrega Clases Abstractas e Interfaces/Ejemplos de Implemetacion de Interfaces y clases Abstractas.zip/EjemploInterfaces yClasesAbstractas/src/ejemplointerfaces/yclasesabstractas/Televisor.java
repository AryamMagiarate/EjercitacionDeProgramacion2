/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemplointerfaces.yclasesabstractas;

/**
 *
 * @author Mayra M.F
 */
public class Televisor extends Aparato implements OnOff{
    private String placa;

    public Televisor(String placa, String nroSerie, String modelo, String fabricante) {
        super(nroSerie, modelo, fabricante);
        this.placa = placa;
    }
    public Televisor(){// Constructor Vacio
    
    }
    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    @Override
    public void encender() {
        System.out.println("El Televisor está encendido.");
    }

    @Override
    public void apagar() {
        System.out.println("El televisor está apagado.");
    }
    
     @Override
    public String darDetalles() {
         System.out.println("---------------------------------------------------------------------------------------------------");
        String detalles="Información Televisor: "+"\nPlaca "+getPlaca()+"\nNúmero de Serie "+getNroSerie()+"\nModelo "+getModelo()+"\nFabricante "+getFabricante();
       
       return detalles; 
    }
}
