/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parcial2prog2mayramagiarate;

/**
 *
 * @author Mayra M.F
 */
public class InscripcionCurso {
    private ClaseCurso claseCurso;
    private long fechaInscripcionCurso;
    private long fechaConfirmada;
    private long marcaFinalizacion;
    private Candidato candidato;

    public InscripcionCurso(ClaseCurso claseCurso, long fechaInscripcionCurso, long fechaConfirmada, long marcaFinalizacion, Candidato candidato) {
        this.claseCurso = claseCurso;
        this.fechaInscripcionCurso = fechaInscripcionCurso;
        this.fechaConfirmada = fechaConfirmada;
        this.marcaFinalizacion = marcaFinalizacion;
        this.candidato = candidato;
    }

   

   

   
    public InscripcionCurso(){
    
    }

    public ClaseCurso getClaseCurso() {
        return claseCurso;
    }

    public void setClaseCurso(ClaseCurso claseCurso) {
        this.claseCurso = claseCurso;
    }

    public long getFechaInscripcionCurso() {
        return fechaInscripcionCurso;
    }

    public void setFechaInscripcionCurso(long fechaInscripcionCurso) {
        this.fechaInscripcionCurso = fechaInscripcionCurso;
    }

    public long getFechaConfirmada() {
        return fechaConfirmada;
    }

    public void setFechaConfirmada(long fechaConfirmada) {
        this.fechaConfirmada = fechaConfirmada;
    }

    public long getMarcaFinalizacion() {
        return marcaFinalizacion;
    }

    public void setMarcaFinalizacion(long marcaFinalizacion) {
        this.marcaFinalizacion = marcaFinalizacion;
    }

    public Candidato getCandidato() {
        return candidato;
    }

    public void setCandidato(Candidato candidato) {
        this.candidato = candidato;
    }

   
    public void infoInscripcion(){
    
        System.out.println("Informacion Inscripcion Curso: \nFecha de inscripción: "+fechaInscripcionCurso+"\nMarca Finalización: "+marcaFinalizacion+"\nFecha Confirmada: "+fechaConfirmada);
    
    
    }
    
}
