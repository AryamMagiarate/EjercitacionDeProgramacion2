/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parcial2prog2mayramagiarate;

/**
 *
 * @author Mayra M.F
 */
public class ClaseCurso {
    private long idSesionCurso;
    private long fechaCurso;
    private String ubicacionCurso;
    private long idCurso;
    private Empleado empleado;

    public ClaseCurso(long idSesionCurso, long fechaCurso, String ubicacionCurso, long idCurso, Empleado empleado) {
        this.idSesionCurso = idSesionCurso;
        this.fechaCurso = fechaCurso;
        this.ubicacionCurso = ubicacionCurso;
        this.idCurso = idCurso;
        this.empleado = empleado;
    }

    

  public ClaseCurso(){
  
  }

    public long getIdSesionCurso() {
        return idSesionCurso;
    }

    public void setIdSesionCurso(long idSesionCurso) {
        this.idSesionCurso = idSesionCurso;
    }

    public long getFechaCurso() {
        return fechaCurso;
    }

    public void setFechaCurso(long fechaCurso) {
        this.fechaCurso = fechaCurso;
    }

    public String getUbicacionCurso() {
        return ubicacionCurso;
    }

    public void setUbicacionCurso(String ubicacionCurso) {
        this.ubicacionCurso = ubicacionCurso;
    }

    public long getIdCurso() {
        return idCurso;
    }

    public void setIdCurso(long idCurso) {
        this.idCurso = idCurso;
    }

    public Empleado getEmpleado() {
        return empleado;
    }

    public void setEmpleado(Empleado empleado) {
        this.empleado = empleado;
    }
  
    
    public String infoClaseCurso(){
       String datosClaseCurso="Informacion Clase Curso: \nId Sesión Curso: "+idSesionCurso+"\nFecha Curso: "+fechaCurso+"\nId Curso: "+idCurso+"\nUbicación Curso: "+ubicacionCurso;
    
    
    return datosClaseCurso;
    }
    
    
}
