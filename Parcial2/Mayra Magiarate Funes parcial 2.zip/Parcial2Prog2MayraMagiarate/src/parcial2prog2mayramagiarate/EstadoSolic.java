/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parcial2prog2mayramagiarate;

/**
 *
 * @author Mayra M.F
 */
public class EstadoSolic {
    private char codigoEstado;
    private String nombreEstado;

    public EstadoSolic(char codigoEstado, String nombreEstado) {
        this.codigoEstado = codigoEstado;
        this.nombreEstado = nombreEstado;
    }
    public EstadoSolic(){
 
 }
    public char getCodigoEstado() {
        return codigoEstado;
    }

    public void setCodigoEstado(char codigoEstado) {
        this.codigoEstado = codigoEstado;
    }

    public String getNombreEstado() {
        return nombreEstado;
    }

    public void setNombreEstado(String nombreEstado) {
        this.nombreEstado = nombreEstado;
    }
    public void infoEstado(){
    
        System.out.println("Informacion Estado: \nCódigo de Estado: "+codigoEstado+"\nNombre Estado: "+nombreEstado);
    
    
    }
    public String AppStatus(String estadoDeLaSolicitud){
        String datosApp="El Estado de la solicitud es: "+estadoDeLaSolicitud;
    
    return datosApp;
    }
    
}
