/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parcial2prog2mayramagiarate;
import java.util.*;
/**
 *
 * @author Mayra M.F
 */
public class Solicitud {
    private Candidato candidato;
   
    private long nProducto;
    private long nivelCertificacion;
    private long fechaSolicitud;
    private ArrayList<CambioEstadoPermitido>cambiosDeEstado=new ArrayList<>();
    private EstadoSolic estado;

    public Solicitud(Candidato candidato, long nProducto, long nivelCertificacion, long fechaSolicitud, EstadoSolic estado) {
        this.candidato = candidato;
        this.nProducto = nProducto;
        this.nivelCertificacion = nivelCertificacion;
        this.fechaSolicitud = fechaSolicitud;
        this.estado = estado;
    }

    
   
    public Solicitud(){
    
    }

    public long getnProducto() {
        return nProducto;
    }

    public void setnProducto(long nProducto) {
        this.nProducto = nProducto;
    }

    public long getNivelCertificacion() {
        return nivelCertificacion;
    }

    public void setNivelCertificacion(long nivelCertificacion) {
        this.nivelCertificacion = nivelCertificacion;
    }

    public long getFechaSolicitud() {
        return fechaSolicitud;
    }

    public void setFechaSolicitud(long fechaSolicitud) {
        this.fechaSolicitud = fechaSolicitud;
    }

    public ArrayList<CambioEstadoPermitido> getCambiosDeEstado() {
        return cambiosDeEstado;
    }

    public void setCambiosDeEstado(ArrayList<CambioEstadoPermitido> cambiosDeEstado) {
        this.cambiosDeEstado = cambiosDeEstado;
    }

    public Candidato getCandidato() {
        return candidato;
    }

    public void setCandidato(Candidato candidato) {
        this.candidato = candidato;
    }

    public EstadoSolic getEstado() {
        return estado;
    }

    public void setEstado(EstadoSolic estado) {
        this.estado = estado;
    }
    
    
   public String infoSolicitud(){
   String datosSolicitud="Informacion de La Solicitud: \n Candidato: "+candidato.infoCandidato()+"\nEstado de la Solicitud: "+estado+"\n Numero de Producto: "+nProducto+"\nNivel Certificación de la Solicitud: "+nivelCertificacion;
   return datosSolicitud;
   } 
    
}
