/*
 * 2.Ejercicio 1 - Implementar desde el diagrama de clases – REQUERIMIENTOS QUE DEBE MOSTRAR POR PANTALLA DE SALIDA DESDE EL METODO MAIN:

-Mencione el nombre y apellido del empleado que se inscribió y a que curso lo hizo.
-Numero de móvil del empleado, provincia y código postal del empleado
-Brinde toda la información de la inscripción (InfoInscripcionCurso) del curso a la que se inscribió el candidato
-Que prueba realizo un candidato
-Que nivel de certificación solicito el candidato
-Brinde toda la información necesaria (InfoExamen) rendida en la prueba del candidato

 */
package parcial2prog2mayramagiarate;

/**
 *
 * @author Mayra M.F
 */
public class Parcial2Prog2MayraMagiarate {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      Empleado empleado1=new Empleado("Informatico",4538,"Diseño","Desarrollo","desarrollador  .Net",1428,"Jorge Arias","2612522510",1988,3988,"Contursi","Jorge Emilio",'e',"Adolfo calle","5500","Mendoza","contuJorgito@outlook.com");
   ClaseCurso fullStack=new ClaseCurso(1234,5520,"UTN FRM",1230,empleado1);
        System.out.println("El Empleado de nombre: "+empleado1.getNombre()+" "+empleado1.getApellido()+"se inscribio al curso "+fullStack.infoClaseCurso());
        System.out.println("El numero de telefono del Empleado es "+empleado1.getnMovil()+" vive en la Provincia de "+empleado1.provincia+" y el codigo postal es: "+empleado1.CP);
      Candidato candidato1=new Candidato("Mayers",".Net dos años","UTN","UBA","Belatrix");
      EstadoSolic estadoSolic1=new EstadoSolic('a',"Aprobado");
        Solicitud solicitud1=new Solicitud(candidato1,452,8,2058, estadoSolic1);
        InscripcionCurso cursoEmpleado=new InscripcionCurso(fullStack,5520,20520,20820,candidato1);
        Examen parcial1=new Examen(1234,4);
        SesionExamen sesionExamen1=new SesionExamen(parcial1,5623,"UTN FRM","12/05/2020");
        Prueba prueba1=new Prueba(85,candidato1,sesionExamen1);
        
  cursoEmpleado.infoInscripcion();
        System.out.println("La prueba que realizó el candidato es: "+prueba1.infoPrueba());
        
        System.out.println("El nivel de certificacion que solicito el candidato es: "+solicitud1.getNivelCertificacion());
        
        System.out.println("La informacion del Examen es: "+parcial1.InfoExamen());
        
        
        
       
      
    
    
    
    }
    
}
