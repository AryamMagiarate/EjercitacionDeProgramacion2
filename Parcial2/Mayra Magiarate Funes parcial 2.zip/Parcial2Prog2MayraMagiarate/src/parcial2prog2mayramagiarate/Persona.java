/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parcial2prog2mayramagiarate;

/**
 *
 * @author Mayra M.F
 */
public class Persona {
    protected long idPersona;
    protected String apellido;
    protected String nombre;
    protected char inicialMedia;
    protected String calle;
    protected String CP;
    protected String provincia;
    protected String direccionElect;

    public Persona(long idPersona, String apellido, String nombre, char inicialMedia, String calle, String CP, String provincia, String direccionElect) {
        this.idPersona = idPersona;
        this.apellido = apellido;
        this.nombre = nombre;
        this.inicialMedia = inicialMedia;
        this.calle = calle;
        this.CP = CP;
        this.provincia = provincia;
        this.direccionElect = direccionElect;
    }
    public Persona(){
    
    
    }

    public long getIdPersona() {
        return idPersona;
    }

    public void setIdPersona(long idPersona) {
        this.idPersona = idPersona;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public char getInicialMedia() {
        return inicialMedia;
    }

    public void setInicialMedia(char inicialMedia) {
        this.inicialMedia = inicialMedia;
    }

    public String getCalle() {
        return calle;
    }

    public void setCalle(String calle) {
        this.calle = calle;
    }

    public String getCP() {
        return CP;
    }

    public void setCP(String CP) {
        this.CP = CP;
    }

    public String getProvincia() {
        return provincia;
    }

    public void setProvincia(String provincia) {
        this.provincia = provincia;
    }

    public String getDireccionElect() {
        return direccionElect;
    }

    public void setDireccionElect(String direccionElect) {
        this.direccionElect = direccionElect;
    }
    
    
public void infoPersona(){
    System.out.println("Informacion de la Persona:\n Nombre: "+nombre+"\nApellido: "+apellido
            +"\nId: "+idPersona+"\nCalle: "+calle+"\nCódigo Postal: "+CP+"\nProvincia: "+provincia+"\nE-mail: "+direccionElect);



}
    
    
    
}
    
    

