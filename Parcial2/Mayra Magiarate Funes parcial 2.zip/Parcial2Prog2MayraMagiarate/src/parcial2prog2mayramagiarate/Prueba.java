/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parcial2prog2mayramagiarate;

/**
 *
 * @author Mayra M.F
 */
public class Prueba {
    private long testScore;
    private Candidato candidatoPrueba;
    private SesionExamen sesionExamenPrueba;

    public Prueba(long testScore, Candidato candidatoPrueba, SesionExamen sesionExamenPrueba) {
        this.testScore = testScore;
        this.candidatoPrueba = candidatoPrueba;
        this.sesionExamenPrueba = sesionExamenPrueba;
    }

    
    public Prueba(){
    
    }

    public long getTestScore() {
        return testScore;
    }

    public void setTestScore(long testScore) {
        this.testScore = testScore;
    }

    public Candidato getCandidatoPrueba() {
        return candidatoPrueba;
    }

    public void setCandidatoPrueba(Candidato candidatoPrueba) {
        this.candidatoPrueba = candidatoPrueba;
    }

    public SesionExamen getSesionExamenPrueba() {
        return sesionExamenPrueba;
    }

    public void setSesionExamenPrueba(SesionExamen sesionExamenPrueba) {
        this.sesionExamenPrueba = sesionExamenPrueba;
    }
    
    public String infoPrueba(){
    
        String datosPrueba="Informacion Prueba: \n TestScore: "+testScore+"\nSesión Examen: "+sesionExamenPrueba.infoSesionExamen()+"\nCandidato: "+candidatoPrueba.infoCandidato();
    return datosPrueba;
    }
    
}
