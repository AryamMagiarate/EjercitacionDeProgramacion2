/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parcial2prog2mayramagiarate;

/**
 *
 * @author Mayra M.F
 */
public class Examen {
    private long idExamen;
    private long nivelCertificacion;

    public Examen(long idExamen, long nivelCertificacion) {
        this.idExamen = idExamen;
        this.nivelCertificacion = nivelCertificacion;
    }
    
    public Examen(){
    }

    public long getIdExamen() {
        return idExamen;
    }

    public void setIdExamen(long idExamen) {
        this.idExamen = idExamen;
    }

    public long getNivelCertificacion() {
        return nivelCertificacion;
    }

    public void setNivelCertificacion(long nivelCertificacion) {
        this.nivelCertificacion = nivelCertificacion;
    }
    
    public String InfoExamen(){
    
       String datosExamen="Informacion Examen: \nId de Examen: "+idExamen+"\nNivel de certificacion: "+nivelCertificacion;
    return datosExamen;
    
    }
}
