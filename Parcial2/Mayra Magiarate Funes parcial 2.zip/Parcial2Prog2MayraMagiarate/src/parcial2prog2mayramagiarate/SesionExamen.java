/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parcial2prog2mayramagiarate;

/**
 *
 * @author Mayra M.F
 */
public class SesionExamen {
    private Examen examen;
    private long sesionExamen;
    private String ubicacionExamen;
    private String fecha;

    public SesionExamen(Examen examen, long sesionExamen, String ubicacionExamen, String fecha) {
        this.examen = new Examen();
        this.sesionExamen = sesionExamen;
        this.ubicacionExamen = ubicacionExamen;
        this.fecha = fecha;
    }
    public SesionExamen(){
    
    }

    public Examen getExamen() {
        return examen;
    }

    public void setExamen(Examen examen) {
        this.examen = examen;
    }

    public long getSesionExamen() {
        return sesionExamen;
    }

    public void setSesionExamen(long sesionExamen) {
        this.sesionExamen = sesionExamen;
    }

    public String getUbicacionExamen() {
        return ubicacionExamen;
    }

    public void setUbicacionExamen(String ubicacionExamen) {
        this.ubicacionExamen = ubicacionExamen;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }
    public String infoSesionExamen(){
    
        String datosExamen="Informacion Sesión Examen: \nSesión Examen: "+sesionExamen+"\nUbicación Examen: "+ubicacionExamen+"\nFecha de Examen: "+fecha;
    return datosExamen;
    }
    
    
}
