/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parcial2prog2mayramagiarate;

/**
 *
 * @author Mayra M.F
 */
public class CambioEstadoPermitido {
    private char deEstado;
    private char aEstado;

    public CambioEstadoPermitido(char deEstado, char aEstado) {
        this.deEstado = deEstado;
        this.aEstado = aEstado;
    }
    public CambioEstadoPermitido(){
    
    }

    public char getDeEstado() {
        return deEstado;
    }

    public void setDeEstado(char deEstado) {
        this.deEstado = deEstado;
    }

    public char getaEstado() {
        return aEstado;
    }

    public void setaEstado(char aEstado) {
        this.aEstado = aEstado;
    }
    public String infoCambioEstado(){
    
        String datosCambioEstado="Informacion de Cambio De Estado: \n Estado Anterior: "+deEstado+"\nEstado Actual: "+aEstado;
    return datosCambioEstado;
    }
    
}
