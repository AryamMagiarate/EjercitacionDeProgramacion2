/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemploagregacion;
import java.util.*;
/**
 *
 * @author Mayra M.F
 */
public class TarjetaDeCredito {
    private String Banco;
    private String nroTarjeta;
    private String fechaAlta;
    private String fechaVenc;
    private String codSeguridad;
   private String titular;

    public TarjetaDeCredito(String Banco, String nroTarjeta, String fechaAlta, String fechaVenc, String codSeguridad) {
        this.Banco = Banco;
        this.nroTarjeta = nroTarjeta;
        this.fechaAlta = fechaAlta;
        this.fechaVenc = fechaVenc;
        this.codSeguridad = codSeguridad;
        this.titular=titular;
    }

  public TarjetaDeCredito(){
  
  }

    public String getBanco() {
        return Banco;
    }

    public void setBanco(String Banco) {
        this.Banco = Banco;
    }

    public String getNroTarjeta() {
        return nroTarjeta;
    }

    public void setNroTarjeta(String nroTarjeta) {
        this.nroTarjeta = nroTarjeta;
    }

    public String getFechaAlta() {
        return fechaAlta;
    }

    public void setFechaAlta(String fechaAlta) {
        this.fechaAlta = fechaAlta;
    }

    public String getFechaVenc() {
        return fechaVenc;
    }

    public void setFechaVenc(String fechaVenc) {
        this.fechaVenc = fechaVenc;
    }

    public String getCodSeguridad() {
        return codSeguridad;
    }

    public void setCodSeguridad(String codSeguridad) {
        this.codSeguridad = codSeguridad;
    }

    public String getTitular() {
        return titular;
    }

    public void setTitular(String titular) {
        this.titular = titular;
    }
    
public void llenarDatos(){
Scanner ingreso=new Scanner(System.in);
    System.out.println("Agrege el Banco: ");
    Banco=ingreso.nextLine();
    System.out.println("Agrege el Nùmero de Tarjeta: ");
    nroTarjeta=ingreso.nextLine();
    System.out.println("Agrege la Fecha de Alta de la Tarjeta: ");
    fechaAlta=ingreso.nextLine();
    System.out.println("Agrege la Fecha de Vencimiento de la Tarjeta: ");
    fechaVenc=ingreso.nextLine();
    System.out.println("Agrege el Código de seguridad de la Tarjeta: ");
    codSeguridad=ingreso.nextLine();
    System.out.println("Agrege el Titular o Propietario de la Tarjeta: ");
    titular=ingreso.nextLine();


}
    
}
