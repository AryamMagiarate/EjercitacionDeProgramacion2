/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemploagregacion;

/**
 *
 * @author Mayra M.F
 */
public class Cliente { // Es la clase contenedora de Tarjeta de Credito
    
    private int id;
    private String nombre;
    private String apellido;
    private TarjetaDeCredito tarjetaDC; // Aqui colocamos al objeto de tipo TarjetaDeCredito como atributo de la clase cliente y le llamamos tarjetaDC, pero no lo inicializamos o instanciamos (no se ve el "new TarjetaDeCredito();")
// Estamos asociando de manera simple una tarjeta de credito a un cliente, o sea un cliente tiene una tarjeta de credito.
    public Cliente() {// Construnctor vacio de la clase Cliente
        //Lo que sea que el construtor haga
    }

    public Cliente(int id, String nombre, String apellido, TarjetaDeCredito tarjetaDC) {
        this.id = id;
        this.nombre = nombre;
        this.apellido = apellido;
        this.tarjetaDC = tarjetaDC;
    }

   

    public void setTarjetaDeCredito(TarjetaDeCredito tarjetaDC) {// Aqui es donde se aplica la asociacion, todos los atributos tendràn sus Setters y Getter, pero el objeto Referenciado o asociado solo tendrà un Setter que es el que permite se asigne un objeto de ese tipo a la clase.
        this.tarjetaDC= tarjetaDC;
    }

    public TarjetaDeCredito getTarjetaDC() {
        return tarjetaDC;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    
    
    
}
