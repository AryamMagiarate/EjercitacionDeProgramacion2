/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemploagregacion;

/**
 *
 * @author Mayra M.F
 */
public class EjemploAgregacion {

    /**La asociacion se podría definir como el momento en que dos objetos se unen para trabajar juntos y así, 
     * alcanzar una meta.
     * Ambos objetos son independientes entre sí o sea que si uno desaparece el otro sigue existiendo.
     * Para ver una asociacion en java o codigo java hay que mirar a las clases que se relacionan, para que haya asociacion, un objeto de una
     * clase1 digamos debe estar referenciado en la clase2 y un objeto de la clase2 debe estar referenciado en la clase1.
La Agregaciòn es un tipo de Asociacion simple, donde un objeto1 de una clase1 està referenciado en una clase2 que  usa o "tiene" a un objeto de la clase1
* o sea, la clase2 usa o tiene un objeto de la clase1, pero la clase1 no tiene un objeto de la clase2 por eso es una agregaciòn o asociación simple
* porque una clase usa o tiene un objeto de otra, sin que la usada tenga que tener un objeto de la que la usa,

     * 
     */
    public static void main(String[] args) {
      
   Cliente cliente1=new Cliente();
   TarjetaDeCredito tarjeta1=new TarjetaDeCredito();
  
   
        
    }
    
}
