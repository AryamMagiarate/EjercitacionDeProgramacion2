/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemplocomposicion;

/**
 *
 * @author Mayra M.F
 */
public class Notebook {
    private String fabricante;
    private String modelo;
    private String  nroSerie;
    private Teclado teclado=new Teclado("Genius","K639"); // aqui creo un objeto y ya comienza su existencia con sus especificaciones, para este 
    // atributo no debo crear ni getters ni setters pues, no deben ser accedidos fuera de la clase para su modificacion, puesto que si cambiamos el
    //atributo de alguna manera, el objeto notebook tambien cambiarà, estos son atributos esenciales.

    public Notebook(String fabricante, String modelo, String nroSerie) {
        this.fabricante = fabricante;
        this.modelo = modelo;
        this.nroSerie = nroSerie;
    }

    public String getFabricante() {
        return fabricante;
    }

    public String getModelo() {
        return modelo;
    }

    public String getNroSerie() {
        return nroSerie;
    }

    public void setFabricante(String fabricante) {
        this.fabricante = fabricante;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public void setNroSerie(String nroSerie) {
        this.nroSerie = nroSerie;
    }
    
    @Override
    public String toString(){
        return "Fabricante: "+fabricante+"\nModelo: "+modelo+"\nNúmero de Serie: "+nroSerie+"\nTeclado: "+teclado.getFabricante(); // como estoy dentro de la clase, puedo usar los getters y setters
    
    
    
    }
}
