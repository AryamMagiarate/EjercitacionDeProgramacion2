/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemplocomposicion;

/**
 *
 * @author Mayra M.F
 */
public class EjemploComposicion {

    /**
     * 
     */
    public static void main(String[] args) {
       Notebook miLaptop=new Notebook("Dell","LatitudeE7470","30387028430"); // como se vè, el constructor no pide el Teclado aun habiendo sido declarado dentro de el .
        System.out.println( miLaptop.toString());// el metodo toString que desarrolle en la clase Notebook permite usar un sout para imprimir los datos del objeto, y se han tenido que usar getters dentro de la clase para poder acceder a los datos del teclado del objeto "miLaptop".
        Teclado nuevoTeclado=new Teclado("Genius","ko4856");
        nuevoTeclado.setFabricante("Dell");
    }
    
}
