/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio1UML;
import java.util.*;
/**
 *
 * @author Mayra M.F
 */
public class Contacto extends Persona {
    private Integer idContacto;
    private ContactoTipo tipo;
    private Vector domicilios=new Vector(3);
    private Vector telefonos=new Vector(20);

    public Contacto(Integer idContacto, ContactoTipo tipo, String nombre, String apellidos, Integer idPersona) {
        super(nombre, apellidos, idPersona);
        this.idContacto = idContacto;
        this.tipo = tipo;
    }

    public Integer getIdContacto() {
        return idContacto;
    }

    public void setIdContacto(Integer idContacto) {
        this.idContacto = idContacto;
    }

    public ContactoTipo getTipo() {
        return tipo;
    }

    public void setTipo(ContactoTipo tipo) {
        this.tipo = tipo;
    }

    public String getDomicilios(ContactoDomicilio contactoDomicilio) {
        String resultado=" ";
        for (int i = 0; i < domicilios.capacity(); i++) {
            resultado= "El "+(1+1)+" Domicilio es: "+domicilios.elementAt(i);
            
        }
        return resultado;
    }

    public void setDomicilios(ContactoDomicilio contactoDomicilio, int index) {
        domicilios.add(index,contactoDomicilio);
    }

    public Vector getTelefonos() {
        return telefonos;
    }

    public void setTelefonos(Vector telefonos) {
        this.telefonos = telefonos;
    }

    @Override
    public String getNombre() {
        return nombre;
    }

    @Override
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    @Override
    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public Integer getIdPersona() {
        return idPersona;
    }

    public void setIdPersona(Integer idPersona) {
        this.idPersona = idPersona;
    }
  

   

 
    
  
    
}
