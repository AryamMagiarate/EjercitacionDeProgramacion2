/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio1UML;

/**
 *
 * @author Mayra M.F
 */
public class Main {
    public static void main(String[]args){
        
  Usuario u1=new Usuario(23564,"Aryam","124551","Mayra","Magiarate Funes",31108782);
  u1.getContactos();
        System.out.println("La Identidad del usuario "+u1.getUsuario()+" es: "+u1.getIdUsuario());
  
    ContactoTipo ct1=new ContactoTipo(12424,"Amigo");
    Contacto c1=new Contacto(1453,ct1,"Facundo","Sosa",41235689);
    ContactoDomicilio cd1=new ContactoDomicilio(1256,"Las moras 1259 ");
  c1.setDomicilios(cd1,1);
    
    
    
    
    
    }// fin main
    
}
