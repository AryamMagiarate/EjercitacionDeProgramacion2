/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio1UML;
import java.util.*;
/**
 *
 * @author Mayra M.F
 */
public class Usuario extends Persona{
    private Integer idUsuario;
    private String usuario;
    private String contraseña;
    private ArrayList<Contacto>contactos=new ArrayList<>(); // hasta mil contactos puede tener

    public Usuario(Integer idUsuario, String usuario, String contraseña, String nombre, String apellidos, Integer idPersona) {
        super(nombre, apellidos, idPersona);
        this.idUsuario = idUsuario;
        this.usuario = usuario;
        this.contraseña = contraseña;
    }

   

    public Integer getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(Integer idUsuario) {
        this.idUsuario = idUsuario;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getContraseña() {
        return contraseña;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }

    public ArrayList<Contacto> getContactos() {
        return contactos;
    }

    public void setContactos(ArrayList<Contacto> contactos) {
        this.contactos = contactos;
    }

    void toString(Integer idUsuario) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

   
    
    
}
