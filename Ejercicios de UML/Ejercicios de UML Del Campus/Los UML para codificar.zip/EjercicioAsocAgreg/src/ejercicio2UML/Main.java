/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio2UML;

/**
 *
 * @author Mayra M.F
 */
public class Main {
    public static void main(String[]args){
    
        Barco barco1=new Barco();
        barco1.setVelocidadMax(8);
        barco1.esquivarObstaculo();
    FordFalcon fal1=new FordFalcon();
        System.out.println("El Falcon tiene "+fal1.nroRuedas+" ruedas");
    Moto moto1=new Moto();
    HondaXR25 moto2=new HondaXR25();
    HondaXR600 lanena=new HondaXR600();
        System.out.println("La Moto XR600 tiene "+lanena.ruedas+" ruedas.");
        System.out.println("Una moto tiene "+moto1.ruedas+" ruedas.");
       
    }
    
}
