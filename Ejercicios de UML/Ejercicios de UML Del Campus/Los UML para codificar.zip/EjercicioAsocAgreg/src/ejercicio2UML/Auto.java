/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio2UML;

import java.util.ArrayList;

/**
 *
 * @author Mayra M.F
 */
public class Auto extends Vehiculo{
    private String modelo;
    private String nroSerie;
     final int nroRuedas=4;

    public Auto(String modelo, String nroSerie, double velocidadPromedio, int velocidadMax, Rueda []rueda) {
        super(velocidadPromedio, velocidadMax, rueda);
        this.modelo = modelo;
        this.nroSerie = nroSerie;
    }

   
   

  
    public Auto(){
    
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getNroSerie() {
        return nroSerie;
    }

    public void setNroSerie(String nroSerie) {
        this.nroSerie = nroSerie;
    }

    
    
    
}
