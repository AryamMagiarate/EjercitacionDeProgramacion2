/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio2UML;

/**
 *
 * @author Mayra M.F
 */
public class Rueda {
    private double diametroGoma;
    private double diametroLLanta;

    public Rueda(double diametroGoma, double diametroLLanta) {
        this.diametroGoma = diametroGoma;
        this.diametroLLanta = diametroLLanta;
    }
    public Rueda(){// Constructor vacio
        
    }

    public double getDiametroGoma() {
        return diametroGoma;
    }

    public void setDiametroGoma(double diametroGoma) {
        this.diametroGoma = diametroGoma;
    }

    public double getDiametroLLanta() {
        return diametroLLanta;
    }

    public void setDiametroLLanta(double diametroLLanta) {
        this.diametroLLanta = diametroLLanta;
    }
    
    
}
