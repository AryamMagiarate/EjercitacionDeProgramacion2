/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio2UML;

/**
 *
 * @author Mayra M.F
 */
public class Boing747 extends Vehiculo{
    private int viajes;

   

    public Boing747(int viajes) {
        this.viajes = viajes;
    }
    
    public Boing747(){
    }

    public int getViajes() {
        return viajes;
    }

    public void setViajes(int viajes) {
        this.viajes = viajes;
    }
    public void despegar(){
        System.out.println("El Avión està despegando.");
    }
    public void aterrizar(){
        System.out.println("El Avión está aterrizando.");
    
    }
    public void agregarViaje(){
    viajes++;
    
    }
    
}
