/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio2UML;
import java.util.*;
/**
 *
 * @author Mayra M.F
 */
public abstract class Vehiculo implements Desplazable{
    private double velocidadPromedio;
    private int velocidadMax;
   private Rueda[] rueda;

    public Vehiculo(double velocidadPromedio, int velocidadMax, Rueda[] rueda) {
        this.velocidadPromedio = velocidadPromedio;
        this.velocidadMax = velocidadMax;
        this.rueda = rueda;
    }

   

   

   

  
    public Vehiculo(){// Constructor vacio
    
    }

  
    
    public double getVelocidadPromedio() {
        return velocidadPromedio;
    }

    public void setVelocidadPromedio(double velocidadPromedio) {
        this.velocidadPromedio = velocidadPromedio;
    }

    public int getVelocidadMax() {
        return velocidadMax;
    }

    public void setVelocidadMax(int velocidadMax) {
        this.velocidadMax = velocidadMax;
    }
    public void romperInercia(){
        System.out.println("El vehiculo se esta moviendo.");
    }

    @Override
    public void esquivarObstaculo() {
        System.out.println("Esquivando Obstaculos.");
    }
    
}
