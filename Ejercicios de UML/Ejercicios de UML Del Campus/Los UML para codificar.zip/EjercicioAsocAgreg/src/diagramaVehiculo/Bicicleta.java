/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package diagramaVehiculo;

/**
 *
 * @author Mayra M.F
 */
public class Bicicleta extends Vehiculo {

    public Bicicleta(int ruedas, String duenio) {
        super(ruedas, duenio);
    }

    @Override
    public String getDuenio() {
        return duenio;
    }

    @Override
    public void setDuenio(String duenio) {
        this.duenio = duenio;
    }

    
    
    
    
    public double precio(double precio) {
        return precio;
       
    }


    public double velocidadMaxima(double velocidad) {
    return velocidad;
    }
    
    public int getRuedas(int ruedas) {
       return ruedas;
    }

    @Override
    public void setRuedas(int ruedas) {
      
    }

    @Override
    public double precio() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public double velocidadMaxima() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int getRuedas() {
       return ruedas;
    }

    
   
    
    
}
