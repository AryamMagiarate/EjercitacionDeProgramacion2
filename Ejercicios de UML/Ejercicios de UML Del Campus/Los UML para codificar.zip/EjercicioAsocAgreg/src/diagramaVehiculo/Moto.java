/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package diagramaVehiculo;

/**
 *
 * @author Mayra M.F
 */
public class Moto extends Vehiculo implements Motor{

    public Moto(int ruedas, String duenio) {
        super(ruedas, duenio);
    }

    @Override
    public int getRuedas() {
        return ruedas;
    }

    @Override
    public String getDuenio() {
        return duenio;
    }

    @Override
    public double precio() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public double velocidadMaxima(double RPMmotor, double circunsfRueda) {
       double velocidad=RPMmotor*circunsfRueda;
        
       return velocidad;
    }

    @Override
    public void setRuedas(int ruedas) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String Tipo() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public double velocidadMaxima() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
}
