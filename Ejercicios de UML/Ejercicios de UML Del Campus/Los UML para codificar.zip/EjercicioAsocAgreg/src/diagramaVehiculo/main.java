/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package diagramaVehiculo;

/**
 *
 * @author Mayra M.F
 */
public class main {
    public static void main(String[]args){
    
    Bicicleta b1=new Bicicleta(2,"Juan Carlos Vives");
    Moto m1=new Moto(2,"Lorenzo Lamas (El renegau)");
        System.out.println("La moto tiene  "+m1.getRuedas()+" ruedas y Su dueño se llama  "+m1.getDuenio());
        System.out.println("La Bicicleta tiene "+b1.getRuedas()+" ruedas y su dueño se llama "+b1.getDuenio());
    
    
    
    }
}
