/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package asociacionComposicion;

/**
 *
 * @author Mayra M.F
 */
public class Recibo extends Comprobante {
    private Proveedor proveedor=new Proveedor(235,"Drogueria Pacífico");
    private float total;
    private String detalle;

    public Recibo(float total, String detalle, char tipo, int numero) {
        super(tipo, numero);
        this.total = total;
        this.detalle = detalle;
    }

    public float getTotal() {
        return total;
    }

    public void setTotal(float total) {
        this.total = total;
    }

    public String getDetalle() {
        return detalle;
    }

    public void setDetalle(String detalle) {
        this.detalle = detalle;
    }
    
    
}
