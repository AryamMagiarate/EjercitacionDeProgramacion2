/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package asociacionComposicion;

/**
 *
 * @author Mayra M.F
 */
public class Comprobante {
    private char tipo;
    private int numero;
    private Fecha fecha=new Fecha(4,9,19);

    public Comprobante(char tipo, int numero) {
        this.tipo = tipo;
        this.numero = numero;
    }

    public char getTipo() {
        return tipo;
    }

    public void setTipo(char tipo) {
        this.tipo = tipo;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

  
    
    
}
