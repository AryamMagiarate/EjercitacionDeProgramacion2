/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicioasocagreg;

/**
 *
 * @author Mayra M.F
 */
public class EjercicioAsocAgreg {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
       Cliente c1=new Cliente();
        c1.setCodigo(124);
        c1.setRazonSocial("Monotributista");
        Producto p1=new Producto(101,"Harina de Trigo 000",40.4f);
        Producto p2=new Producto(103,"Aceite de Girasol 1.5L",98.3f);
        Factura f1=new Factura();
        f1.setCliente(c1);
        f1.addProducto(p1);
        f1.addProducto(p2);
        
        
        
       
    }
    
}
