/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicioasocagreg;
import java.util.*;
/**
 *
 * @author Mayra M.F
 */
public class Factura extends Comprobante {
    private float total;
    private Cliente cliente;
    private ArrayList<Producto>productos=new ArrayList<>();

    public Factura(float total, Cliente cliente) {
        this.total = total;
        this.cliente = cliente;
    }
    
    public Factura() {

    }

    public float getTotal() {
        return total;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public ArrayList<Producto> getProductos() {
        return productos;
    }

    public void setTotal(float total) {
        this.total = total;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }
  public void addProducto(Producto producto){ // esto es un mètodo para agregar productos (creados en el main o en otra clase que llame a este mètodo)
      //  al ArrayList productos que pertenece a esta clase.
   productos.add(producto);
  
  }
  
    
}
