/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ejercicio2Herencia;

/**
 *
 * @author Mayra M.F
 */
public class Mixer extends Electrodomesticos{
    private boolean cuchillaRemovible;
    private boolean setBatidor;
    private boolean setPicador;

    public Mixer(boolean cuchillaRemovible, boolean setBatidor, boolean setPicador, String fabricante, String nroSerie, String modelo) {
        super(fabricante, nroSerie, modelo);
        this.cuchillaRemovible = cuchillaRemovible;
        this.setBatidor = setBatidor;
        this.setPicador = setPicador;
    }

   

    public boolean isCuchillaRemovible() {
        return cuchillaRemovible;
    }

    public void setCuchillaRemovible(boolean cuchillaRemovible) {
        this.cuchillaRemovible = cuchillaRemovible;
    }

    public boolean isSetBatidor() {
        return setBatidor;
    }

    public void setSetBatidor(boolean setBatidor) {
        this.setBatidor = setBatidor;
    }

    public boolean isSetPicador() {
        return setPicador;
    }

    public void setSetPicador(boolean setPicador) {
        this.setPicador = setPicador;
    }
    
    
}
