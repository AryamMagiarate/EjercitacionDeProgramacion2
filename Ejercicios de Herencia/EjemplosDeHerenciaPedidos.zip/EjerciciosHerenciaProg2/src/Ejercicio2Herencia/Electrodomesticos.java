/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ejercicio2Herencia;

/**
 *
 * @author Mayra M.F
 */
public class Electrodomesticos {
    protected String fabricante;
    protected String nroSerie;
    protected String modelo;

    public Electrodomesticos(String fabricante, String nroSerie, String modelo) {
        this.fabricante = fabricante;
        this.nroSerie = nroSerie;
        this.modelo = modelo;
    }

    public String getFabricante() {
        return fabricante;
    }

    public void setFabricante(String fabricante) {
        this.fabricante = fabricante;
    }

    public String getNroSerie() {
        return nroSerie;
    }

    public void setNroSerie(String nroSerie) {
        this.nroSerie = nroSerie;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }
    public void mostrarDatos(){
        System.out.println("Fabricante: "+fabricante+ " Modelo: "+modelo+" Número de Serie: "+nroSerie);
    
    
    }
    
}
