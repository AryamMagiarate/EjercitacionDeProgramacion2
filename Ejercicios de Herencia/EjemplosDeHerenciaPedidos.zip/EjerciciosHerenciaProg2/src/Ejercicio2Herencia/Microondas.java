/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ejercicio2Herencia;

/**
 *
 * @author Mayra M.F
 */
public class Microondas extends Electrodomesticos{
    private int capacidadEnLitros;
    private double potenciaEnKw;
    private boolean grill;

    public Microondas(int capacidadEnLitros, double potenciaEnKw, boolean grill, String fabricante, String nroSerie, String modelo) {
        super(fabricante, nroSerie, modelo);
        this.capacidadEnLitros = capacidadEnLitros;
        this.potenciaEnKw = potenciaEnKw;
        this.grill = grill;
    }

    public int getCapacidadEnLitros() {
        return capacidadEnLitros;
    }

    public void setCapacidadEnLitros(int capacidadEnLitros) {
        this.capacidadEnLitros = capacidadEnLitros;
    }

    public double getPotenciaEnKw() {
        return potenciaEnKw;
    }

    public void setPotenciaEnKw(double potenciaEnKw) {
        this.potenciaEnKw = potenciaEnKw;
    }

    public boolean isGrill() {
        return grill;
    }

    public void setGrill(boolean grill) {
        this.grill = grill;
    }
    
    
    
}
