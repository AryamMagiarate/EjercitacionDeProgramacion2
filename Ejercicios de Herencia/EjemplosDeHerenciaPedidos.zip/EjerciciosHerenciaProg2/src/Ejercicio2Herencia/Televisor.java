/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ejercicio2Herencia;

/**
 *
 * @author Mayra M.F
 */
public class Televisor extends Electrodomesticos {
    private int pulgadasPantalla;
    private boolean smartTv;
    private int cantidadDePuertosUsb;
    
    public Televisor(int pulgadasPantalla, boolean smartTv, int cantidadDePuertosUsb, String fabricante, String nroSerie, String modelo) {
        super(fabricante, nroSerie, modelo);
        this.pulgadasPantalla = pulgadasPantalla;
        this.smartTv = smartTv;
        this.cantidadDePuertosUsb = cantidadDePuertosUsb;
    }


    public int getPulgadasPantalla() {
        return pulgadasPantalla;
    }

    public void setPulgadasPantalla(int pulgadasPantalla) {
        this.pulgadasPantalla = pulgadasPantalla;
    }

    public boolean isSmartTv() {
        return smartTv;
    }

    public void setSmartTv(boolean smartTv) {
        this.smartTv = smartTv;
    }

    public int getCantidadDePuertosUsb() {
        return cantidadDePuertosUsb;
    }

    public void setCantidadDePuertosUsb(int cantidadDePuertosUsb) {
        this.cantidadDePuertosUsb = cantidadDePuertosUsb;
    }
    
    
    
}
