/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ejercicio2Herencia;

/**
 *
 * @author Mayra M.F
 */
public class main {
    public static void main(String[]args){
    
    Heladera heladera1=new Heladera(310,true,"Blanco","Siam","12564po","Stand");
        System.out.println("Heladera\n Fabricante: "+heladera1.getFabricante());// este es un atributo que la clase Heladera Heredó de Electrodomestico, sale sin el get porque no generè los getters y setter en la clase hija, ya que puedo utilizar los de la clase padre.
    
    Microondas microondas1=new Microondas(30, 1200.0,true, "Panasonic","mi3215784","EasyCook");
        System.out.println("Fabricante: "+microondas1.getFabricante()+" Modelo: "+microondas1.getModelo());
    
    Mixer miPimer=new Mixer(true,true,false,"UrsusTrotter","US2354l","Basic");
   miPimer.mostrarDatos(); // mostrarà los atributos que ha heredado, justamente porque tambien heredó el metodo mostrarDatos de la Clase Electrodomesticos.
    
    }
    
}
