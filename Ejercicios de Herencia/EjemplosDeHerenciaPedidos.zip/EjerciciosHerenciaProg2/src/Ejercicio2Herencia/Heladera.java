/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ejercicio2Herencia;

/**
 *
 * @author Mayra M.F
 */
public class Heladera extends Electrodomesticos {
    private int capacidadEnLitros;
    private boolean freezer;
    private String color;

    public Heladera(int capacidadEnLitros, boolean freezer, String color, String fabricante, String nroSerie, String modelo) {
        super(fabricante, nroSerie, modelo);
        this.capacidadEnLitros = capacidadEnLitros;
        this.freezer = freezer;
        this.color = color;
    }

    public int getCapacidadEnLitros() {
        return capacidadEnLitros;
    }

    public void setCapacidadEnLitros(int capacidadEnLitros) {
        this.capacidadEnLitros = capacidadEnLitros;
    }

    public boolean isFreezer() {
        return freezer;
    }

    public void setFreezer(boolean freezer) {
        this.freezer = freezer;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

  
    
}
