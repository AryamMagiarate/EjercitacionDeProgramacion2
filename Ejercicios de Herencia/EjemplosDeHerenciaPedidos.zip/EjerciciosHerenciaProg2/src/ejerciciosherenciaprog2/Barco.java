/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejerciciosherenciaprog2;

/**
 *
 * @author Mayra M.F
 */
public class Barco extends Vehiculo {
    private String nombre; // si los barcos y embarcaciones tienen que tener nombre.
    private String motorTipo;
    private String tipoDeCasco;
    private String tipoDeVela;

    public Barco(String nombre, String motorTipo, String tipoDeCasco, String tipoDeVela, double capacidadDeCargaKg, int capacidadDePersonas) {
        super(capacidadDeCargaKg, capacidadDePersonas);
        this.nombre = nombre;
        this.motorTipo = motorTipo;
        this.tipoDeCasco = tipoDeCasco;
        this.tipoDeVela = tipoDeVela;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getMotorTipo() {
        return motorTipo;
    }

    public void setMotorTipo(String motorTipo) {
        this.motorTipo = motorTipo;
    }

    public String getTipoDeCasco() {
        return tipoDeCasco;
    }

    public void setTipoDeCasco(String tipoDeCasco) {
        this.tipoDeCasco = tipoDeCasco;
    }

    public String getTipoDeVela() {
        return tipoDeVela;
    }

    public void setTipoDeVela(String tipoDeVela) {
        this.tipoDeVela = tipoDeVela;
    }

    @Override
    public double getCapacidadDeCargaKg() {
        return capacidadDeCargaKg;
    }

    @Override
    public void setCapacidadDeCargaKg(double capacidadDeCargaKg) {
        this.capacidadDeCargaKg = capacidadDeCargaKg;
    }

    @Override
    public int getCapacidadDePersonas() {
        return capacidadDePersonas;
    }

    public void setCapacidadDePersonas(int capacidadDePersonas) {
        this.capacidadDePersonas = capacidadDePersonas;
    }

    
    
    
    
    
}
