/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejerciciosherenciaprog2;

/**
 *
 * @author Mayra M.F
 */
public class Automovil extends Vehiculo{
    private final int catidadDeRuedas=4;
    private String modelo;

    public Automovil(String modelo, double capacidadDeCargaKg, int capacidadDePersonas) {
        super(capacidadDeCargaKg, capacidadDePersonas);
        this.modelo = modelo;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public double getCapacidadDeCargaKg() {
        return capacidadDeCargaKg;
    }

    public void setCapacidadDeCargaKg(double capacidadDeCargaKg) {
        this.capacidadDeCargaKg = capacidadDeCargaKg;
    }

    public int getCapacidadDePersonas() {
        return capacidadDePersonas;
    }

    public void setCapacidadDePersonas(int capacidadDePersonas) {
        this.capacidadDePersonas = capacidadDePersonas;
    }
    
    
}
