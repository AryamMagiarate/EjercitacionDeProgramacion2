/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejerciciosherenciaprog2;

/**
 *
 * @author Mayra M.F
 */
public class Bicicleta extends Vehiculo{
    private final int cantidadDeRuedas=2;
    private String tipoDeBici;
    private String tipoDeAciento;
    private boolean canasto;
    private boolean parrilla;

    public Bicicleta(String tipoDeBici, String tipoDeAciento, boolean canasto, boolean parrilla, double capacidadDeCargaKg, int capacidadDePersonas) {
        super(capacidadDeCargaKg, capacidadDePersonas);
        this.tipoDeBici = tipoDeBici;
        this.tipoDeAciento = tipoDeAciento;
        this.canasto = canasto;
        this.parrilla = parrilla;
       
        
    }

    public String getTipoDeBici() {
        return tipoDeBici;
    }

    public void setTipoDeBici(String tipoDeBici) {
        this.tipoDeBici = tipoDeBici;
    }

    public String getTipoDeAciento() {
        return tipoDeAciento;
    }

    public void setTipoDeAciento(String tipoDeAciento) {
        this.tipoDeAciento = tipoDeAciento;
    }

    public boolean isCanasto() {
        return canasto;
    }

    public void setCanasto(boolean canasto) {
        this.canasto = canasto;
    }

    public boolean isParrilla() {
        return parrilla;
    }

    public void setParrilla(boolean parrilla) {
        this.parrilla = parrilla;
    }

    @Override
    public double getCapacidadDeCargaKg() {
        return capacidadDeCargaKg;
    }

    @Override
    public void setCapacidadDeCargaKg(double capacidadDeCargaKg) {
        this.capacidadDeCargaKg = capacidadDeCargaKg;
    }

    @Override
    public int getCapacidadDePersonas() {
        if (parrilla) {capacidadDePersonas=2;
            
        }
        return capacidadDePersonas;
    }

    @Override
    public void setCapacidadDePersonas(int capacidadDePersonas) {
        this.capacidadDePersonas = capacidadDePersonas;
    }

    
    
    
}
