/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejerciciosherenciaprog2;

/**
 *
 * @author Mayra M.F
 */
public class Vehiculo {
    protected double capacidadDeCargaKg;
    protected int capacidadDePersonas;

    public Vehiculo(double capacidadDeCargaKg, int capacidadDePersonas) {
        this.capacidadDeCargaKg = capacidadDeCargaKg;
        this.capacidadDePersonas = capacidadDePersonas;
    }

    public double getCapacidadDeCargaKg() {
        return capacidadDeCargaKg;
    }

    public void setCapacidadDeCargaKg(double capacidadDeCargaKg) {
        this.capacidadDeCargaKg = capacidadDeCargaKg;
    }

    public int getCapacidadDePersonas() {
        return capacidadDePersonas;
    }

    public void setCapacidadDePersonas(int capacidadDePersonas) {
        this.capacidadDePersonas = capacidadDePersonas;
    }

    
    
}
