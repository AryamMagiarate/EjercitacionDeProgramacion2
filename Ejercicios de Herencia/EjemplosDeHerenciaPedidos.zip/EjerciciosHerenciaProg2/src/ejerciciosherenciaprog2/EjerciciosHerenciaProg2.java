/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejerciciosherenciaprog2;

/**
 *
 * @author Mayra M.F
 */
public class EjerciciosHerenciaProg2 {

    /**
     * Ejercicios de Herencia, clases padre y clases hijas pedidos como Tarea.
     */
    public static void main(String[] args) {
        
        Automovil auto1=new Automovil("Ford Falcon",1000.50,7);
        Bicicleta bici1=new Bicicleta("Dama","Playero", true,true,210.2,1);
        System.out.println(bici1.getCapacidadDePersonas());
        System.out.println("Modelo: "+auto1.getModelo()+"\nPuede llevar: "+auto1.getCapacidadDePersonas()+" de Personas.");
        
        
        
        
        
      
    }
    
}
