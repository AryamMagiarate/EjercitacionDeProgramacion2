/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bankmanager;

/**
 *
 * @author Mayra M.F
 */
public class CertificateOfDeposit extends BankAccount {
    
   private String fecha;
   public CertificateOfDeposit(){
   }

    public CertificateOfDeposit(String fecha) {
        this.fecha = fecha;
    }

    public CertificateOfDeposit(String fecha, String account, double balance) {
        super(account, balance);
        this.fecha = fecha;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }
   
    
}
