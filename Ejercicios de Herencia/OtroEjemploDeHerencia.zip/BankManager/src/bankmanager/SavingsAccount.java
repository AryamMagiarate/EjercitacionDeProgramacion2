/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bankmanager;

/**
 *
 * @author Mayra M.F
 */
public class SavingsAccount extends BankAccount{
    private int cod;

    public SavingsAccount() {
        
    }

    public SavingsAccount(int cod, String account, double balance) {
        super(account, balance);
        this.cod = cod;
    }

    public int getCod() {
        return cod;
    }

    public void setCod(int cod) {
        this.cod = cod;
    }
      public void mostrarDatos(){
   
       System.out.println("\nSavingsAccount\n"+"Account: "+ account+"\n Balance: "+ balance+"\n Código: "+cod);
       
  
   }
    
}
