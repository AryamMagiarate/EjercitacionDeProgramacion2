/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bankmanager;

/**
 *
 * @author Mayra M.F
 */
public class BankManager {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    
        BankAccount ba1=new BankAccount();// creo el objeto BankAccount llamado Ba1.
      CheckingAccount ca1=new CheckingAccount();
      SavingsAccount sa1=new SavingsAccount();
      sa1.setAccount("128-458sa");
      ca1.setAccount("123-898ca");
      sa1.setBalance(124.56);
        ca1.setBalance(895.45);
        sa1.setCod(567);
        ca1.setLimit(8000.00);
        sa1.mostrarDatos();
        ca1.mostrarDatos();
        
    }
    
}
