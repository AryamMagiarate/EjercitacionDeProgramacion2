/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bankmanager;
import java.util.*;
/**
 *
 * @author Mayra M.F
 */
public class CheckingAccount extends BankAccount {
    private double limit;

    public CheckingAccount() { // constructor standar vacio
    
    }

    public CheckingAccount(double limit, String account, double balance) {
        super(account, balance);
        this.limit = limit;
    }

    public double getLimit() { // como vemos solo podemos generar los getters y setters para el atributo limit, pues los otros atriubutos son heredados y poseen esos metodos que tambien son heredados, o sea seria redundante
        return limit;
    }

    public void setLimit(double limit) {
        this.limit = limit;
    }
    
   public void mostrarDatos(){
   
       System.out.println("\nCheckingAccount\n"+"Account: "+ account+"\n Balance: "+ balance+"\n Limit: "+limit);
       
  
   }
}
